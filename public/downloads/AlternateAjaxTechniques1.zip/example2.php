<?php
    header("Content-type: text/javascript");
?>

var sMessage = "Hello, ";
var sName = "<?php echo $_GET['name'] ?>";

<?php echo $_GET['callback'] ?>(sMessage + sName);