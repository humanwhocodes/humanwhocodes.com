insert into StatesAndProvinces(Name)
values ('Alabama');;

insert into StatesAndProvinces(Name)
values ('Arizona');

insert into StatesAndProvinces(Name)
values ('Arkansas');

insert into StatesAndProvinces(Name)
values ('California');

insert into StatesAndProvinces(Name)
values ('Colorado');

insert into StatesAndProvinces(Name)
values ('Connecticut');

insert into StatesAndProvinces(Name)
values ('Delaware');

insert into StatesAndProvinces(Name)
values ('Florida');

insert into StatesAndProvinces(Name)
values ('Georgia');

insert into StatesAndProvinces(Name)
values ('Hawaii');

insert into StatesAndProvinces(Name)
values ('Idaho');

insert into StatesAndProvinces(Name)
values ('Illinois');

insert into StatesAndProvinces(Name)
values ('Indiana');

insert into StatesAndProvinces(Name)
values ('Iowa');

insert into StatesAndProvinces(Name)
values ('Kansas');

insert into StatesAndProvinces(Name)
values ('Kentucky');

insert into StatesAndProvinces(Name)
values ('Louisiana');

insert into StatesAndProvinces(Name)
values ('Maine');

insert into StatesAndProvinces(Name)
values ('Maryland');

insert into StatesAndProvinces(Name)
values ('Massachusetts');

insert into StatesAndProvinces(Name)
values ('Michigan');

insert into StatesAndProvinces(Name)
values ('Minnesota');

insert into StatesAndProvinces(Name)
values ('Mississippi');

insert into StatesAndProvinces(Name)
values ('Missouri');

insert into StatesAndProvinces(Name)
values ('Montana');

insert into StatesAndProvinces(Name)
values ('Nebraska');

insert into StatesAndProvinces(Name)
values ('Nevada');

insert into StatesAndProvinces(Name)
values ('New Hampshire');

insert into StatesAndProvinces(Name)
values ('New Mexico');

insert into StatesAndProvinces(Name)
values ('New York');

insert into StatesAndProvinces(Name)
values ('North Carolina');

insert into StatesAndProvinces(Name)
values ('North Dakota');

insert into StatesAndProvinces(Name)
values ('Ohio');

insert into StatesAndProvinces(Name)
values ('Oklahoma');

insert into StatesAndProvinces(Name)
values ('Oregon');

insert into StatesAndProvinces(Name)
values ('Pennsylvania');

insert into StatesAndProvinces(Name)
values ('Rhode Island');

insert into StatesAndProvinces(Name)
values ('South Carolina');

insert into StatesAndProvinces(Name)
values ('South Dakota');

insert into StatesAndProvinces(Name)
values ('Tennessee');

insert into StatesAndProvinces(Name)
values ('Texas');

insert into StatesAndProvinces(Name)
values ('Utah');

insert into StatesAndProvinces(Name)
values ('Vermont');

insert into StatesAndProvinces(Name)
values ('Virginia');

insert into StatesAndProvinces(Name)
values ('Washington');

insert into StatesAndProvinces(Name)
values ('West Virginia');

insert into StatesAndProvinces(Name)
values ('Wisconsin');

insert into StatesAndProvinces(Name)
values ('Wyoming');