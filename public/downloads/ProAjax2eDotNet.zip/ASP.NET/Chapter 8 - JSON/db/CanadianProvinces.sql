insert into StatesAndProvinces(Name)
values ('Alberta'); 

insert into StatesAndProvinces(Name)
 values  ('British Columbia'); 

insert into StatesAndProvinces(Name) 
values  ('Manitoba'); 

insert into StatesAndProvinces(Name) 
values  ('New Brunswick'); 

insert into StatesAndProvinces(Name) 
values ('Newfoundland and Labrador'); 

insert into StatesAndProvinces(Name) 
values  ('Northwest Territories'); 

insert into StatesAndProvinces(Name) 
values  ('Nova Scotia'); 

insert into StatesAndProvinces(Name) 
values ('Halifax'); 

insert into StatesAndProvinces(Name) 
values  ('Quebec'); 

insert into StatesAndProvinces(Name) 
values  ('Nunavut'); 

insert into StatesAndProvinces(Name) 
values  ('Ontario'); 

insert into StatesAndProvinces(Name) 
values  ('Prince Edward Island'); 

insert into StatesAndProvinces(Name) 
values  ('Saskatchewan'); 

insert into StatesAndProvinces(Name) 
values  ('Yukon');

