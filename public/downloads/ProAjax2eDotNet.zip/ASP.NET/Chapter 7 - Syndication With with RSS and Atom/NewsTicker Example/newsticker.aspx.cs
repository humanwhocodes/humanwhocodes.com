using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class newsticker : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Set the headers
        Response.CacheControl = "No-cache";
        Response.ContentType = "text/xml";

        //Does the url argument exist?
        if (Request.QueryString["url"] != null)
        {
            Uri url = null;
            //Try to parse it into a URL
            try
            {
                url = new Uri(Request.QueryString["url"]);
            }
            //It failed for some reason. To take the easy way out, set the status as 500.
            catch (UriFormatException exception)
            {
                Response.StatusCode = 500;
                Response.End();
            }

            //Use a WebClient
            using (System.Net.WebClient client = new System.Net.WebClient())
            {
                //Retrieve and read the feed
                try
                {
                    using (System.IO.StreamReader reader = new System.IO.StreamReader(client.OpenRead(url)))
                    {
                        Response.Write(reader.ReadToEnd()); //output it to the Response
                    }
                }
                catch (System.Net.WebException exception)
                {
                    Response.StatusCode = 500;
                    Response.End();
                }
            }
        }
        else
        {
            Response.StatusCode = 500;
            Response.End();
        }
    }
}
