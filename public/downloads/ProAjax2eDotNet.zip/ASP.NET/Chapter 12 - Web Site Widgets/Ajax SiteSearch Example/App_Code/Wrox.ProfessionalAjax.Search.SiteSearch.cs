using System;
using System.Collections;
using System.Configuration;
using System.Data.SqlClient;
using Newtonsoft.Json;

namespace Wrox.ProfessionalAjax
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public static class AjaxSiteSearch
	{
		public static string Search (string searchString) 
		{
            //Get our connection string.
            string conString =
                ConfigurationManager.ConnectionStrings["SiteSearch"].ConnectionString;

            //Build the query.
            string query = String.Format("SELECT TOP 10 BlogId, " +
                "Title FROM BlogPosts WHERE Post LIKE '%{0}%' " +
                "OR Title LIKE '%{0}%' ORDER BY Date DESC", searchString);

            //Initialize the JSON Array
            ArrayList searchResults = new ArrayList();

            //Setup the database connection
            using (SqlConnection conn = new SqlConnection(conString))
            {
                //And get the command ready
                SqlCommand command = new SqlCommand(query, conn);
                //Open the connection
                conn.Open();

                //Perform the query.
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    try
                    {
                        //If we got results...
                        if (reader.HasRows)
                        {
                            
                            //Add the info to the JSON Array
                            while (reader.Read())
                            {
                                searchResults.Add(new SearchResult(reader["BlogId"].ToString(), reader["Title"].ToString()));
                            }
                        }
                    }
                    catch { }
                }
            }

            //Return the information.
            return JavaScriptConvert.SerializeObject(searchResults);
		}
	}
}
