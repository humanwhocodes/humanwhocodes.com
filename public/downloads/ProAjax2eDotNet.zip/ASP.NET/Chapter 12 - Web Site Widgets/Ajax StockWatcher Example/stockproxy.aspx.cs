using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using Newtonsoft.Json;

public partial class stockproxy : System.Web.UI.Page
{
    private string[] symbols;

    private string symbolString
    {
        get
        {
            try
            {
                if (symbols.Length > 0)
                {
                    string temp = String.Empty;

                    foreach (string symbol in symbols)
                    {
                        temp += symbol + "+";
                    }

                    return temp.Remove(temp.LastIndexOf('+'));
                }
            }
            catch (NullReferenceException exception)
            {
                throw new Exception("The symbols array has not be initialized.");
            }

            return String.Empty;
        }

    }

    protected void Page_Load(object sender, EventArgs e)
    {
        Response.CacheControl = "no-cache";
        Response.ContentType = "text/plain; charset=UTF-8";

        symbols = new string[] { "MSFT", "GE" };

        getStockQuotes();

    }

    private void getStockQuotes()
    {
        Uri url = new Uri(String.Format("http://finance.yahoo.com/d/quotes.csv?s={0}&f=snl1c1", symbolString));

        ReturnedData returnedData = new ReturnedData();
        
        using (System.Net.WebClient client = new System.Net.WebClient())
        {
            //Retrieve and read the feed
            try
            {
                using (System.IO.StreamReader reader = new System.IO.StreamReader(client.OpenRead(url)))
                {
                    string data = reader.ReadToEnd();
                    data = data.Replace("\"", String.Empty);

                    string[] newData = data.Split(new string[] { System.Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);

                    returnedData.error = false;

                    //JSONArray jsonStockArray = new JSONArray();

                    foreach (string stockData in newData)
                    {
                        returnedData.stocks.Add(new Stock(stockData));
                    }
                }
            }
            catch (System.Net.WebException exception)
            {
                returnedData.error = true;
            }

            Response.Write(JavaScriptConvert.SerializeObject(returnedData));
        }
    }   
}
