﻿using System;
using System.Configuration;
using System.Xml;

namespace Wrox.ProfessionalAjax.Weather
{
	/// <summary>
	/// The settings for Weather.com SDK.
	/// </summary>
	public static class Settings
	{
        /// <summary>
        /// Returns the license key assigned by Weather.com.
        /// </summary>
        public static string LicenseKey
        {
            get
            {
                return ConfigurationManager.AppSettings["license"];
            }
        }

        /// <summary>
        /// Returns the partner ID.
        /// </summary>
		public static string PartnerId
		{
			get
			{
                return ConfigurationManager.AppSettings["partner"];
			}
		}

        /// <summary>
        /// Returns the location id.
        /// </summary>
        public static string LocationId
		{
			get
			{
                return ConfigurationManager.AppSettings["location"];
			}
		}
	}
}
