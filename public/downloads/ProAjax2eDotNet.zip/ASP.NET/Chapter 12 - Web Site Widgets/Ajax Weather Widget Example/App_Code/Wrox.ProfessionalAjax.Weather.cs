using System;
using System.IO;
using System.Net;
using System.Xml;
using System.Xml.Xsl;

namespace Wrox.ProfessionalAjax.Weather
{
	/// <summary>
	/// A simple class to pull a weather feed from Weather.com's XOAP service.
	/// </summary>
	public class WeatherInfo
	{
		private string _path;
		private string _cachedFile;
		
		/// <summary>
		/// The Weather class constructor.
		/// </summary>
		/// <param name="path">The path to the application (Server.MapPath(""))</param>
		public WeatherInfo(string path)
		{
			_path = path;
			_cachedFile = String.Format(@"{0}\weather_cache.xml",_path);
		}

		/// <summary>
		/// Gets the weather feed either from a cached file or straight from the Web.
		/// </summary>
		/// <returns>A string containing the XML feed from the Weather.com service.</returns>
		public string GetWeather()
		{
			DateTime timeLimit = LastModified.AddMinutes(30);
			
			//Check the time. If it's been thirty minutes since the cached
			//file's been written, then pull a new feed.
			if (DateTime.Now.CompareTo(timeLimit) > -1)
			{
				//Time to pull a new feed.
				return _getWebWeather();
			} 
			else 
			{
				return _getCachedWeather();
			}
		}
		
		/// <summary>
		/// Gets the cached feed.
		/// </summary>
		/// <returns>A string containing the XML feed from the Weather.com service.</returns>
		private string _getCachedWeather()
		{
			string str = String.Empty;
			
			//Open and read the cached weather feed.
			using (StreamReader reader = new StreamReader(_cachedFile))
			{
				str = reader.ReadToEnd();
			}
			
			//Return the contents
			return str;
		}

		/// <summary>
		/// Gets the feed from the Weather.com XOAP service.
		/// </summary>
		/// <returns>A string containing the XML feed from the Weather.com service.</returns>
        private string _getWebWeather()
        {
            //Just to keep things clean, an unformatted URL:
            string baseUrl = "http://xoap.weather.com/weather/local/{0}?cc=*&prod=xoap&par={1}&key={2}";

            //Now format the url with the needed information
            string url = String.Format(baseUrl, Settings.LocationId, Settings.PartnerId, Settings.LicenseKey);

            //Use a web client. It's less coding than an HttpWebRequest.
            using (WebClient client = new WebClient())
            {
                //Read the results
                try
                {
                    //throw new WebException();
                    //Create an XmlReader to read the response
                    XmlTextReader xml = new XmlTextReader(client.OpenRead(url));

                    //Get the XSLT object ready
                    XslCompiledTransform xslt = new XslCompiledTransform();
                    xslt.Load(_path + "/weather.xslt");

                    //Write the resulting XSLT to the cache file
                    using (StreamWriter writer = new StreamWriter(_cachedFile))
                    {
                        xslt.Transform(xml, null, writer);
                    }

                    //return the cached copy
                    return _getCachedWeather();
                }
                catch (WebException exception)
                {
                    //Write up the XML, and put in the exception info
                    string xmlStr = "<errorDoc>";
                    xmlStr += "<alert>An Error Occurred!</alert>";
                    xmlStr += String.Format("<message>{0}</message>", exception.Message);
                    xmlStr += "</errorDoc>";

                    //Load it into an XmlDocument
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(xmlStr);

                    //And put it into an XmlReader
                    XmlNodeReader reader = new XmlNodeReader(doc);

                    //XSLT
                    XslCompiledTransform xslt = new XslCompiledTransform();
                    xslt.Load(_path + "/weather.xslt");

                    //Load the XmlWriter data into the result document
                    XmlDocument resultDocument = new XmlDocument();
                    using (XmlWriter writer = resultDocument.CreateNavigator().AppendChild())
                    {
                        xslt.Transform(reader, (XsltArgumentList) null, writer);
                    }

                    //Output the serialized XML
                    return resultDocument.OuterXml;
                }
            }            
        }

		public DateTime LastModified 
		{
			get 
			{
				if ((File.Exists(_cachedFile))) 
				{ 
					//If so, grab it's time.
					return File.GetLastWriteTime(_cachedFile);
				} 
				else 
				{
					//If not, then set to an early time.
					return new DateTime(1, 1, 1);
				}
			}
		}
	}
}
