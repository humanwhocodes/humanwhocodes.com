The Web.config file has already been updated with the appropriate code to use Ajax.NET Professional.

The Visual Studio Web Site is contained in AjaxProExample. Load this into Visual Studio and then add the Ajax.NET Professional files.

The SQL script to create the database table is included in the DB folder.