<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
     "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Home page</title>
        <script type="text/javascript" src="zxml.js"></script>
        <script type="text/javascript" src="CommentChecker.js"></script>
        <link rel="stylesheet" type="text/css" href="PeriodicRefresh.css" />
    </head>
    <body>
        <p>This page could be any page on the site, it doesn't necessarily
        have to be a blog page or even an important one. The only thing that's
        important is that the periodic refresh JavaScript is included.</p>
        <p>Leave this page open in one browser window and open up Comment.php
        in another. Using that page, post a comment. Within a minute or so,
        you should see a notification on this page indicating that a new comment
        was posted.</p>
    </body>
</html>
