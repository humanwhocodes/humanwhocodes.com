using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;

/// <summary>
/// Summary description for FooReaderError
/// </summary>
public static class FooReaderError
{

    public static string WriteErrorDocument(Exception exception)
    {
        string xml = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>";
        xml += "<rss version=\"2.0\">";
        xml += "<channel>";
        xml += "<title>FooReader Error</title>";
        xml += "<description>FooReader Error</description> ";
        xml += "<link>javascript:void(0);</link>";
        xml += "<item>";
        xml += "<pubDate>Just Now</pubDate>";
        xml += String.Format("<title>FooReader Error: {0}</title>", exception.GetType().ToString());
        xml += "<description>";
        xml += "<![CDATA[";
        xml += "<p>An error occurred.</p>";
        xml += String.Format("<p style='color: red'>{0}</p>", exception.Message);
        xml += "]]>";
        xml += "</description>";
        xml += "<link>javascript:void(0);</link>";
        xml += "</item>";
        xml += "</channel> ";
        xml += "</rss>";	

        return xml;
    }
}
