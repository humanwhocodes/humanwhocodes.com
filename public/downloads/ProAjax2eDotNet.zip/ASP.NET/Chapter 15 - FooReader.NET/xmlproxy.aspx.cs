using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class xmlproxy : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.ContentType = "text/xml";
        Response.CacheControl = "No-cache";

        if (Request.QueryString["feed"] != null)
        {
            Uri url = null;

            try
            {
                url = new Uri(Request.QueryString["feed"]);
            }
            catch (UriFormatException exception)
            {
                Response.Write(FooReaderError.WriteErrorDocument(exception));

                Response.End();
            }

            string fileName = String.Format(@"{0}\xml\{1}.xml", Server.MapPath(String.Empty), HttpUtility.UrlEncode(url.AbsoluteUri));

            try
            {
                System.Net.HttpWebRequest request = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(url);

                request.UserAgent = "FooReader.NET 1.5 (http://reader.wdonline.com)";
                request.Timeout = 5000;

                using (System.Net.HttpWebResponse response = (System.Net.HttpWebResponse)request.GetResponse())
                {
                    using (System.IO.StreamReader reader = new System.IO.StreamReader(response.GetResponseStream()))
                    {
                        string feedXml = reader.ReadToEnd();

                        using (System.IO.StreamWriter writer = new System.IO.StreamWriter(fileName))
                        {
                            writer.Write(feedXml);
                        }

                        Response.Write(feedXml);
                    }
                }
            }
            catch (System.Net.WebException exception)
            {
                if (System.IO.File.Exists(fileName))
                {
                    Response.Write(getLocalFile(fileName));
                }
                else
                {
                    Response.Write(FooReaderError.WriteErrorDocument(exception));
                }
            }
            catch (System.IO.IOException exception)
            {
                //do nothing here
            }
            catch (Exception exception)
            {
                Response.Write(FooReaderError.WriteErrorDocument(exception));
            }
        }
        else
        {
            try
            {
                throw new Exception("No feed specified for retrieval.");
            }
            catch (Exception exception)
            {
                Response.Write(FooReaderError.WriteErrorDocument(exception));
            }
        }
    }

    private string getLocalFile(string path)
    {
        string contents = String.Empty;
        using (System.IO.StreamReader file = System.IO.File.OpenText(path))
        {
            contents = file.ReadToEnd();
        }
        return contents;
    }
}
