using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class posttest : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.ContentType = "text/plain";
        Response.CacheControl = "No-cache";

        if (Request.Form["name"] != null)
        {
            
            string name = Request.Form["name"].ToString();
            Response.Write("Hello, " + name + "!");
        }
        else
        {
            Response.Write("I'm sorry, but no name could be found");
        }
    }
}
