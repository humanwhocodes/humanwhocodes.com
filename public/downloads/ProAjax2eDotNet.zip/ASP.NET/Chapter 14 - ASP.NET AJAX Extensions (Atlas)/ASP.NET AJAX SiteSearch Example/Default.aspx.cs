using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        foreach (Control control in plhResults.Controls)
            plhResults.Controls.Remove(control);

        txtSearchTerm.Text = String.Empty;
    }

    protected void ScriptManager1_AsyncPostBackError(object sender, AsyncPostBackErrorEventArgs e)
    {
        ScriptManager1.AsyncPostBackErrorMessage = e.Exception.Message;
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        //Get the search string
        string searchString = txtSearchTerm.Text;

        //Check to see if anything was entered.
        //If not, tell the user to enter text.
        if (searchString == String.Empty)
        {
            throw new Exception("Please enter a search term.");
        }
        else
        {
            //Get our connection string.
            string connectionString = ConfigurationManager.ConnectionStrings["SiteSearch"].ConnectionString;
            //Build the query.
            string query = String.Format("SELECT TOP 10 BlogId, " +
                "Title FROM BlogPosts WHERE Post LIKE '%{0}%' " +
                "OR Title LIKE '%{0}%' ORDER BY Date DESC", searchString);

            //Setup the database connection
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                //And get the command ready
                SqlCommand command = new SqlCommand(query, conn);
                //Open the connection.
                conn.Open();

                //Perform the query.
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    //If we got results...
                    if (reader.HasRows)
                    {
                        //Loop through them
                        while (reader.Read())
                        {
                            //Create a link
                            HyperLink link = new HyperLink();

                            link.Text = reader["Title"].ToString();
                            link.NavigateUrl = "http://www.yoursite.com/" + reader["BlogId"].ToString();
                            link.CssClass = "ajaxSiteSearchLink";

                            //Add it to the PlaceHolder
                            plhResults.Controls.Add(link);
                        }
                    }
                    else //No results found
                    {
                        throw new Exception("No match could be found.");
                    }
                }
            }
        }
    }
}