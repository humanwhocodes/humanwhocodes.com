To run this example, download the Java MySQL drivers from:

    http://dev.mysql.com/downloads/connector/j/5.0.html

And download version 1.1.3 of DWR at:
    
    http://getahead.ltd.uk/dwr/download

Also, CustomerInfo.java should be compiled to CustomerInfo.class before running this example.