--------------------------
JSONLib 0.1 Alpha
--------------------------

Introduction
------------
JSONLib is an open source (LGPL) JavaScript library designed to ease the use and security
issues surrounding JSON. The library provides two objects that enable complete JSON access
without the security issues. The JSON parser is based on Douglas Crockford's original
JSON parser written in JavaScript.

Author
------
Nicholas C. Zakas, http://www.nczonline.net

ECMAScript Support
------------------
Known To Work:
- ECMAScript Edition 3

Known To Fail:
- ECMAScript Edition 1
- ECMAScript Edition 2

Browser Support
---------------
Known To Work:
- Internet Explorer 5.5+
- Mozilla 1.0+

Assumed To Work:
- Opera 8.0+
- Safari 1.0+

Assumed To Fail:
- Opera 7.x
- Internet Explorer 3.0-5.0
- Netscape 4.x
- Netscape 3.x
- Netscape 2.x

Release Notes
----------------
Version 0.1 Alpha - January 15, 2008
- Initial release.


