//JavaScript zInherit Library v1.0 by Nicholas C. Zakas, http://www.nczonline.net
//This library governed by the GNU Lesser General Public License
Object.prototype.inheritFrom=function($a){function inheritClasses($a,$b){$b.push($a);if(typeof $a.$d=="object"){for(var i=0;i<$a.$d.length;i++){inheritClasses($a.$d[i],$b);}}};if(typeof this.constructor.$d=="undefined"){this.constructor.$d=new Array();};inheritClasses($a,this.constructor.$d);for($z in $a.prototype){if(typeof $a.prototype[$z]=="function"){this[$z]=$a.prototype[$z];}}};Object.prototype.instanceOf=function($a){if(this.constructor==$a){return true;}else if(typeof this.constructor.$d=="object"){for(var i=0;i<this.constructor.$d.length;i++){if(this.constructor.$d[i]==$a){return true;}};return false;}else{return false;}};

