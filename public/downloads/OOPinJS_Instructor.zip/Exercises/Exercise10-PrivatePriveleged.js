function Person(personName) {

    var name = personName;
    
    this.getName = function() {
        return name;
    };
    
    this.setName = function(newName) {
        name = newName;
    };

}