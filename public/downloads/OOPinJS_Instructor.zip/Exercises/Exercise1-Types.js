function isString(value) {
    return typeof value == "string";
}

function isNumber(value) {
    return typeof value == "number";
}

function isBoolean(value) {
    return typeof value == "boolean";
}

function isUndefined(value) {
    return typeof value == "undefined";
}

function isNull(value) {
    return value === null;
}
