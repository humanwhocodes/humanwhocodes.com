var computer = {

    os: "Windows",
    
    about: function() {
        console.log(this.os);
    }

};


computer.about();