var car = {
    make: "Toyota",
    model: "Celica"
};
