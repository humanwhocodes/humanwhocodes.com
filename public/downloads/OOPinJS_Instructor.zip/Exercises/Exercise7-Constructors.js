

function Rectangle(width, height) {
    this.width = width;
    this.height = height;
        
    Object.defineProperty(this, "area", {
        enumerable: false,
        configurable: false,
        get: function() {
            return this.width * this.height;
        }
    });
    
    this.sayWidth = function() {
        console.log(this.width);
    };
    
    this.sayHeight = function() {
        console.log(this.height);
    };
    
    this.sayArea = function() {
        console.log(this.area);
    }
}

var rectangle = new Rectangle(50, 50);

console.log("Area is: " + rectangle.area);
