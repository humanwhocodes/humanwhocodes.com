
var rectangle = { 
    width: 50, 
    height: 50 
};


Object.defineProperty(rectangle, "area", {
    enumerable: false,
    configurable: false,
    get: function() {
        return this.width * this.height;
    }

});

console.log("Area is: " + rectangle.area);
