var computer = {

    os: "Windows",
    
    about: function() {
        console.log(this.os);
    }

};


computer.memory = 256;

for (var prop in computer) {
    console.log(prop);
    console.log(computer[prop]);
}

delete computer.os;

for (var prop in computer) {
    console.log(prop);
    console.log(computer[prop]);
}