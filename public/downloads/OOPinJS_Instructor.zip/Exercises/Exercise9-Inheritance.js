function Device(os, version, pointer) {
    this.os = os;
    this.version = version;
    this.pointer = pointer;
}

Device.prototype = {
    constructor: Device,

    sayOS: function(){
        console.log(this.os);
    },

    sayVersion: function() {
        console.log(this.version);
    },

    sayPointer: function() {
        console.log(this.pointer);
    }
};





function MobileDevice(os, version) {
    Device.call(this, os, version, "touch");
}

MobileDevice.prototype = Object.create(Device.prototype);





function DesktopDevice(os, version) {
    Device.call(this, os, version, "mouse");
}

DesktopDevice.prototype = Object.create(DesktopDevice.prototype);
