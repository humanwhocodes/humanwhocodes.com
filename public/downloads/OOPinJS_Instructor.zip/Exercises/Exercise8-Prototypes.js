

function Rectangle(width, height) {
    this.width = width;
    this.height = height;
}

Rectangle.prototype = {

    sayWidth: function() {
        console.log(this.width);
    },
    
    sayHeight: function() {
        console.log(this.height);
    },
    
    sayArea: function() {
        console.log(this.area);
    }

};

Object.defineProperty(Rectangle.prototype, "area", {
    enumerable: false,
    configurable: false,
    get: function() {
        return this.width * this.height;
    }
});


var rectangle = new Rectangle(50, 50);
console.log("Area is: " + rectangle.area);
