--------------------------
zArray 1.01
--------------------------

Introduction
------------
zArray is an open source (LGPL) JavaScript library designed to augment the 
default Array implementation with new methods as well as methods implemented
in other browsers.

Browser Support
---------------
Known To Work:
- Internet Explorer 5.5+
- Mozilla 1.0+
- Opera 7.0+

Assumed To Work:
- Opera 5.0+
- Safari 1.0+
- Netscape 4.x
- Internet Explorer 3.0-5.0
- Netscape 3.x

Directory Structure
-------------------
* distrib  - Files that are crunched and obfuscated for distribution.
* doc      - HTML documentation for this JavaScript library.
* examples - Several sample files making use of the JavaScript library.
* src      - Commented source code files.      

Release Notes
----------------
Version 1.1 (August 18, 2005)
- Updated every() to return true for empty arrays.
- Added append() method.
- Added sum() method.
Version 1.01 (August 1, 2005)
- Fixed incorrect implementation of every().
Version 1.0 (July 31, 2005)
- Initial release.


