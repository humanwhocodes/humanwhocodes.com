--------------------------
zXml 1.0.2
--------------------------

Introduction
------------
zXml is an open source (LGPL) JavaScript library designed to equalize differences
in XML and XMLHttp features across browsers. Using this library allows you to
avoid code forks by utilizing simple, cross-browser methods to perform common
XML-based operations.

Author
------
Nicholas C. Zakas, http://www.nczonline.net

Contributors
------------
Jeremy McPeak, http://www.wdonline.com/
Joe Fawcett, http://joef.typepad.com/

ECMAScript Support
------------------
Known To Work:
- ECMAScript Edition 3

Known To Fail:
- ECMAScript Edition 1
- ECMAScript Edition 2

Browser Support
---------------
Known To Work:
- Internet Explorer 5.5+
- Mozilla 1.0+

Assumed To Work (XMLHttp only):
- Opera 8.0+
- Safari 1.0+

Assumed To Fail:
- Opera 7.x
- Internet Explorer 3.0-5.0
- Netscape 4.x
- Netscape 3.x
- Netscape 2.x

Directory Structure
-------------------
* distrib  - Files that are crunched and obfuscated for distribution.
* doc      - HTML documentation for this JavaScript library.
* examples - Several sample files making use of the JavaScript library.
* src      - Commented source code files.      

Release Notes
----------------
Version 1.0.2 - October 27, 2006
- Updated the progID lists for ActiveX versions of XMLHttp and XML DOM for IE.

Version 1.0.1 - September 23, 2006
- Fixed small bug in zXPath involving namespaces in IE.

Version 1.0 - September 1, 2005
- Initial release.


