<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
<title>Untitled</title>
</head>
<body>
<?php 
    if (isset($_FILES['myfile'])) {
        echo print_r($_FILES['myfile']);
    }
 ?>
 <script>
     var oForm = null;
     
     function doSomething() {
         oForm= frames[0].document.forms[0];
         oForm.myfile.click();
         if (oForm.myfile.value.length > 0) {
             oForm.btn.click();
         }
     }
     
     function callback(sFilename) {
         alert("You uploaded: " + sFilename);
     }
 </script>
<a href="#" onclick="doSomething(); return false">Click Me To Upload</a>


<iframe name="uploadframe" src="testfile2.php" style="visibility: hidden"></iframe>
</body>
</html>
