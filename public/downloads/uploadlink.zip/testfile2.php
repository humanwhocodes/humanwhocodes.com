<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
<title>Upload Form</title>
</head>
<body>
<?php 
    if (isset($_FILES['myfile'])) {
?>
    <script type="text/javascript">
       window.onload = function () {
           parent.callback("<?php echo $_FILES['myfile']['name'] ?>");
       }
    </script>

<?php    
        echo print_r($_FILES['myfile']);
    }
 ?>
<form action="testfile2.php" method="post" enctype="multipart/form-data">
    <input type="button" id="btn" name="btn" onclick="document.forms[0].submit()" />
    <input type="file" id="myfile" name="myfile" />
</form>
</body>
</html>
