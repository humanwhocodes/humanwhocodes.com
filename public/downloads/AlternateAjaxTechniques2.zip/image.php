<?php
    header("Content-type: image/gif");
    setcookie("info", "Hello, ".$_GET["name"]);
    header("Location: pixel.gif");
?>