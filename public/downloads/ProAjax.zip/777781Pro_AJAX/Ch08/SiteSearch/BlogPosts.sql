CREATE TABLE BlogPosts (
	id int IDENTITY (1, 1) NOT NULL,
	date datetime NOT NULL,
	title text NOT NULL,
	posting text NOT NULL 
)