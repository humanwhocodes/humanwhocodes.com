insert into StatesAndProvinces(Name)
values ('Alberta'), ('British Columbia'), ('Manitoba'), ('New Brunswick'),
('Newfoundland and Labrador'), ('Northwest Territories'), ('Nova Scotia'),
('Halifax'), ('Quebec'), ('Nunavut'), ('Ontario'), ('Prince Edward Island'), ('Saskatchewan'), ('Yukon');

