--------------------------
zDragDrop 1.1.1
--------------------------

Introduction
------------
zDragDrop is an open source (LGPL) JavaScript library designed to ease the creation of drag and drop functionality in DOM  Web browsers. 
Author
------
Nicholas C. Zakas, http://www.nczonline.net

Contributors
------------
Jeremy McPeak, http://www.wdonline.com
Jose Jeria

ECMAScript Support
------------------
Known To Work:
- ECMAScript Edition 3

Known To Fail:
- ECMAScript Edition 1
- ECMAScript Edition 2

Browser Support
---------------
Known To Work:
- Internet Explorer 5.5+
- Mozilla 1.0+

Assumed To Work:
- Opera 8.0+
- Safari 1.0+

Assumed To Fail:
- Opera 7.x
- Internet Explorer 3.0-5.0
- Netscape 4.x
- Netscape 3.x
- Netscape 2.x

Directory Structure
-------------------
* distrib  - Files that are crunched and obfuscated for distribution.
* doc      - HTML documentation for this JavaScript library.
* examples - Several sample files making use of the JavaScript library.
* src      - Commented source code files.      

Release Notes
----------------
Version 1.1 - October 29, 2005
- Fixed bug that caused zDragDrop to fail when used with a XHTML strict doctype.
Version 1.0 - December 10, 2004
- Initial release.


