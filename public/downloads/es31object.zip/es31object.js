/*
 * Copyright (c) 2008 Nicholas C. Zakas
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 * 
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 * 
 */

/*
 * Object.create()
 * Limitations: 
 * - IE cannot define getters or setters for properties.
 * - No browsers can define enumerable, flexible, or writable on properties as this functionality isn't available in today's browsers.
 */
Object.create = function(proto, props){

    //create new object
    function F(){}
    F.prototype = proto;
    var object = new F();
    
    //if __proto__ isn't defined, define it
    if (!object.__proto__){
        object.__proto__ = proto;
    }
    
    //copy over properties
    if (typeof props == "object"){
        Object.defineProperties(object, props);
    }
    
    //return it
    return object;
};

/*
 * Object.clone()
 * Limitations: 
 * - Prototype retrieval may fail in IE, making this method fail.
 */
Object.clone = function(original){
    var copy = Object.create(Object.getPrototypeOf(original)),
        keys = Object.getOwnPropertyNames(original),
        i = 0,
        len = keys.length;
        
    for (; i < len; i++){
        copy[keys[i]] = original[keys[i]];
    }
    
    return copy;
};

/*
 * Object.defineProperty()
 * Limitations: 
 * - IE cannot define getters or setters for properties.
 * - Once assigned, a property's getters/setters cannot be removed.
 * - No browsers can define enumerable, flexible, or writable on properties as this functionality isn't available in today's browsers.
 */
Object.defineProperty = function(object, name, desc){
    if (desc.value){
        object[name] = desc.value;
        
        if (desc.getter)
    } else {
        //sorry IE, you suck
        if (desc.getter){
            object.__defineGetter__(name, desc.getter);
        }
        
        if (desc.setter){
            object.__defineSetter__(name, desc.setter);
        }
    }
    //other stuff not really able to do
    return object;
};

/*
 * Object.defineProperties()
 * Limitations: 
 * - IE cannot define getters or setters for properties.
 * - Once assigned, a property's getters/setters cannot be removed. 
 * - No browsers can define enumerable, flexible, or writable on properties as this functionality isn't available in today's browsers.
 */
Object.defineProperties = function(object, props){
    var keys = Object.keys(props),
        i = 0,
        len = keys.length;
        
    for (; i < len; i++){
        Object.defineProperty(object, keys[i], props[keys[i]]);
    }
    return object;
};

/*
 * Object.getPrototypeOf()
 * Limitations: 
 * - May be inaccurate in browsers that don't native support __proto__
 */
Object.getPrototypeOf = function(object){
    if (typeof object.__proto__ != "undefined"){
        return object.__proto__;
    } else { //pray
        return object.constructor.prototype;
    }
};

/*
 * Object.getOwnPropertyNames()
 * Limitations: 
 * - Returns same values as Object.keys() because no browsers allow you to define non-enumerable properties.
 */
Object.getOwnPropertyNames = function(object){
    //not entirely accurate...real implementation would also include non-enumerable properties, oh well
    return Object.keys(object, true);
};

/*
 * Object.getOwnPropertyDescriptor()
 * Limitations: 
 * - IE cannot define getters/setters, so these will always be undefined in IE.
 * - No browsers can define enumerable, flexible, or writable on properties, so these are all set to true.
 */
Object.getOwnPropertyDescriptor = function(object, prop){
    if (!object.hasOwnProperty(prop)){
        return; //returns undefined per spec
    } else {
        var descriptor = {
            value: object[prop],
            getter: undefined,
            setter: undefined,
            enumerable: true,
            writable: true,
            flexible: true
        };
            
        if (object.__lookupGetter__){
            var getter = object.__lookupGetter__(prop),
                setter = object.__lookupSetter__(prop);
                
            if (getter || setter){
                descriptor.value = undefined;
                descriptor.getter = getter;
                descriptor.setter = setter;
            }
        }
        
        return descriptor;
    }
};

/*
 * Object.keys()
 * Limitations: 
 * - None.
 */
Object.keys = function(object, fast){
    var props = [],
        prop;
        
    for (prop in object){
        if (object.hasOwnProperty(prop) && prop != "__proto__"){  //hack for IE
            props.push(prop);
        }
    }
    
    if (!fast){
        props.sort();
    }
    return props;
};

