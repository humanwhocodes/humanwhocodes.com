--------------------------
zColor 0.1
--------------------------

Introduction
------------
zColor is an open source (LGPL) JavaScript library designed to make color
manipulation in JavaScript easier. The library consists of objects to represent
various aspects of color.

ECMAScript Support
------------------
Known To Work:
- ECMAScript Edition 3

Assumed To Work:
- ECMAScript Edition 1
- ECMAScript Edition 2

Browser Support
---------------
Known To Work:
- Internet Explorer 5.5+
- Mozilla 1.0+
- Opera 7.0+

Assumed To Work:
- Opera 5.0+
- Safari 1.0+
- Netscape 4.x
- Netscape 3.x
- Internet Explorer 3.0-5.0

Assumed To Fail:
- Netscape 2.x

Directory Structure
-------------------
* distrib  - Files that are crunched and obfuscated for distribution.
* doc      - HTML documentation for this JavaScript library.
* examples - Several sample files making use of the JavaScript library.
* src      - Commented source code files.      

Release Notes
----------------
Version 0.1
- Contains zRGB and zHSL classes, providing for conversion between the two formats.


