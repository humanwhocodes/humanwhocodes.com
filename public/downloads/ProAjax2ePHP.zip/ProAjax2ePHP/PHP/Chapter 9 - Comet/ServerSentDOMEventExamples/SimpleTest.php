<?php

while(true) {
    echo "Event: click\n";
    echo "Target: #btnTest\n";
    echo "screenX: 10\n";
    echo "screenY: 25\n";
    echo "\n";
    flush();
    sleep(10);
}
?>