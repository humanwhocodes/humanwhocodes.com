<?php

    // current time
    echo date('h:i:s') . "\n";

    // sleep for 10 seconds
    sleep(10);

    // wake up !
    echo date('h:i:s') . "\n";

?>
