<?php

define("LICENSE", "");
define("PARTNER", "");
define("LOCATION", "");

?>
