<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" 
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Hidden Frame GET Example</title>
</head>
<frameset rows="100%,0" style="border: 0px">
    <frame name="displayFrame" src="DataDisplay.php" noresize="noresize"  style="border: 0px" />
    <frame name="hiddenFrame" src="about:blank" noresize="noresize" style="border: 0px" />
</frameset>
</html>
