<?php

    header("Content-Type: image/jpeg");

    $sID = $_GET["id"];
    $sName = mysql_real_escape_string($_POST["txtName"]);
    
    if (is_numeric($sID)) {
        $iWidth = 1;
        
        $sDBServer = "your.database.server";
        $sDBName = "your_db_name";
        $sDBUsername = "your_db_username";
        $sDBPassword = "your_db_password";

        $sSQL = "Update Customers set `Name` = '$sName' where CustomerId=$sID";

        $oLink = mysql_connect($sDBServer,$sDBUsername,$sDBPassword);
        @mysql_select_db($sDBName) or $iWidth = 3;
        
        if ($iWidth == 1) {
            if (mysql_query($sSQL)) {
                $iWidth = (mysql_affected_rows() > 0) ? 1 : 2;
                mysql_close($oLink);
            } else {
                $iWidth = 3;
            }
        }
    } else {
        $iWidth = 2;
    }
    
    $image = imagecreate($iWidth,1);
    $white = imagecolorallocate($image, 255, 255, 255);    
    imagejpeg($image);
    imagedestroy($image);
?>
