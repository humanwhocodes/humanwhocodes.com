<?php
    header("Content-type: image/gif");
    header("Location: pixel.gif");
?>
